# react-admin-lte-3.0.4

ReactJS version of the original AdminLTE basic dashboard.

## Instructions to run

- Fork or clone this repo
- Install nodejs and NPM
- Go to the project root folder from your terminal and run npm install
- Run npm run start
